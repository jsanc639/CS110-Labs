import { useState, useEffect } from 'react'
import Title from './components/Title'
import Sidebar from './components/Sidebar'
import ArticleCard from './components/ArticleCard'
import './App.css'

function App() {
  const [sortType, setSortType] = useState("shared")
  const [timePeriod, setTimePeriod] = useState("30")
  const [articles, setArticles] = useState([])
  const [articleCount, setArticleCount] = useState(6)
  const [currentPage, setCurrentPage] = useState(1)
  const [articlesPerPage] = useState(6)
  const visibleArticles = articles
  .slice(0, articleCount)
  .slice((currentPage - 1) * articlesPerPage, currentPage * articlesPerPage)
  const leftArticles = visibleArticles.filter((_, index) => index % 2 === 0)
  const rightArticles = visibleArticles.filter((_, index) => index % 2 !== 0)

  const getArticles = async () => {
    try {
      const url = `https://api.nytimes.com/svc/mostpopular/v2/${sortType}/${timePeriod}.json?api-key=1rLe5VJoJdfCwKQC66cGAXEX3udbWvrdUn8oNlww6HtUYmPo`
      const response = await fetch(url)
      const data = await response.json()
      setArticles(data.results.slice(0, 15))
    } catch (error) {
      console.error('Error:', error)
    }
  }

  useEffect(() => {
    getArticles()
  }, [sortType, timePeriod])

  return (
  <div>
    <Title sortType={sortType} timePeriod={timePeriod} />
    <div className="main-container">
      <Sidebar 
        setSortType={setSortType} 
        setTimePeriod={setTimePeriod}
        articleCount={articleCount}
        setArticleCount={setArticleCount}
      />
      <main className="articles-list">
        <div className="columns-container">
          <div className="column">
            {leftArticles.map(article => (
              <ArticleCard key={article.url} article={article} />
            ))}
          </div>
          <div className="column">
            {rightArticles.map(article => (
              <ArticleCard key={article.url} article={article} />
            ))}
          </div>
        </div>
        <div className="pagination">
          {Array.from({ length: Math.ceil(articleCount / articlesPerPage) }, (_, i) => (
            <button
              key={i + 1}
              onClick={() => setCurrentPage(i + 1)}
              style={{ fontWeight: currentPage === i + 1 ? 'bold' : 'normal' }}
            >
              {i + 1}
            </button>
          ))}
        </div>
      </main>
    </div>
  </div>
  )
}

export default App