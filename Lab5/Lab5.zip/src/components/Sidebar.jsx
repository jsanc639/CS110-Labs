
function Sidebar({ setSortType, setTimePeriod, articleCount, setArticleCount }) {

  function handleCountChange(e) {
    const value = Number(e.target.value)
    if (value > 15) {
      alert("number is higher than 15")
    } else {
      setArticleCount(value)
    }
  }

  return (
    <aside className="filter-menu">
      <h2>Filter</h2>

      <div className="filter-group">
        <h3>Number of articles:</h3>
        <input 
          type="number" 
          value={articleCount} 
          onChange={handleCountChange}
        />
      </div>

      <div className="filter-group">
        <h3>Sort By:</h3>
        <label><input type="radio" name="sortType" value="viewed" onChange={e => setSortType(e.target.value)} /> Most Viewed</label>
        <label><input type="radio" name="sortType" value="shared" defaultChecked onChange={e => setSortType(e.target.value)} /> Most Shared</label>
        <label><input type="radio" name="sortType" value="emailed" onChange={e => setSortType(e.target.value)} /> Most Emailed</label>
      </div>

      <div className="filter-group">
        <h3>Time Frame:</h3>
        <label><input type="radio" name="timePeriod" value="1" onChange={e => setTimePeriod(e.target.value)} /> Day</label>
        <label><input type="radio" name="timePeriod" value="7" onChange={e => setTimePeriod(e.target.value)} /> Week</label>
        <label><input type="radio" name="timePeriod" value="30" defaultChecked onChange={e => setTimePeriod(e.target.value)} /> Month</label>
      </div>
    </aside>
  )
}
export default Sidebar