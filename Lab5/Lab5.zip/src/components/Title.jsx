function Title({ sortType, timePeriod }) {

  const sortLabels = {
    viewed: "Most Viewed",
    shared: "Most Shared",
    emailed: "Most Emailed"
  }

  const periodLabels = {
    "1": "Day",
    "7": "Week",
    "30": "Month"
  }

  return (
    <h1>{sortLabels[sortType]} - {periodLabels[timePeriod]}</h1>
  )
}

export default Title