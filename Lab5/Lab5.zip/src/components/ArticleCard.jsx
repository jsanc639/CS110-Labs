function getImageUrl(article) {
  const mediaItem = article.media[0]
  if (!mediaItem || mediaItem.type !== "image") return null
  const formats = mediaItem["media-metadata"]
  const preferred = formats.find(f => f.format === "mediumThreeByTwo210")
  return preferred ? preferred.url : formats[formats.length - 1]?.url ?? null
}

function ArticleCard({ article }) {
  const imageUrl = getImageUrl(article)

  if (!imageUrl || !article.title || !article.abstract) {
    return (
      <div className="article-card">
        <img src="https://placehold.co/150x100" alt="Not available" />
        <div className="article-content">
          <h3>Article not available</h3>
          <p>This article could not be loaded.</p>
        </div>
      </div>
    )
  }
  return (
  <div className="article-card">
    <img src={imageUrl} alt={article.title} />
    <div className="article-content">
      <div className="article-header">
        <h3><a href={article.url} target="_blank" rel="noopener noreferrer">{article.title}</a></h3>
        <span className="article-date">{article.published_date}</span>
      </div>
      <p>{article.abstract}</p>
    </div>
  </div>
  )
}

export default ArticleCard